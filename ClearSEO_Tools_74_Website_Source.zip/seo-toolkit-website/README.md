# ClearSEO Tools

A free, client-side SEO utility suite with 70+ working tools. The tools analyze user-supplied text, HTML, CSV exports and page metadata. They do not claim to reproduce proprietary keyword, backlink, competitor-traffic or AI-visibility databases.

## Included

- Keyword research helpers: cleanup, intent heuristics, modifiers, clustering, mapping, cannibalization and manual gap comparison.
- On-page checks: title, description, heading structure, keyword density, readability, image alt, links, social metadata, canonical, robots and hreflang.
- Technical SEO: public URL fetch, basic page audit, sitemap builder/parser, robots rules, indexability signals, redirect review, links, logs, CWV CSV and `llms.txt` draft.
- Content workflows: briefs, topic clusters, FAQ/question ideas, refresh prioritization, repeated phrase checks, text similarity and answer blocks.
- Backlinks and outreach: imported backlink CSV summaries, anchor distributions, manual link gap, disavow draft and outreach prioritization.
- Local/schema: NAP comparison, review response drafts and LocalBusiness, FAQ, Article and Organization JSON-LD generators.
- GEO/AEO: content readiness checklist, entity coverage, citation extraction, prompt hypotheses and manual brand-mention tracking.
- Analytics/PPC/social: GSC and GA4 CSV summaries, regex, PPC match-type formatting, negative keyword ideas and social copy length checks.

## Local setup

Requires Node.js 20 or later. There are no runtime or build dependencies to install.

```bash
npm run dev
```

Open the local URL printed by Vite. All browser-only tools work locally. The live URL checker and page auditor need the deployed Pages Function at `/api/fetch`; those two tools will not work under the plain Vite dev server unless you add a local function proxy.

Run the repeatable smoke tests and build a production bundle:

```bash
npm run test:smoke
npm run build
npm run preview
```

## Deploy free starter to Cloudflare Pages

1. Create a GitHub repository and push this folder to it.
2. In Cloudflare Dashboard, open **Workers & Pages** and create a Pages project connected to the repository.
3. Framework preset: **None / Other** (this project uses a dependency-free Node build, not Vite).
4. Build command: `npm run build`.
5. Build output directory: `dist`.
6. Deploy. Cloudflare Pages detects the root-level `functions/` directory and deploys `functions/api/fetch.js` as `/api/fetch`.
7. Test a public URL using **Live URL Response Checker** and **Single-Page Technical SEO Audit**.

Cloudflare's published Pages Free limits currently include up to 500 builds/month, 20,000 files per site and 25 MiB per individual file. Function calls use Workers quotas. Check current limits and terms before a commercial launch.

## Optional Vercel deployment

1. Import the GitHub repository into Vercel.
2. Framework preset: Other / None.
3. Build command: `npm run build`.
4. Output directory: `dist`.

A Vercel Node Function adapter is included at `api/fetch.js`, so both live URL tools can work there. Vercel documents its Hobby plan as for personal, non-commercial use. For a revenue-generating public service, choose a host/plan whose terms permit commercial use.

## Data and accuracy boundaries

- No keyword volume, keyword difficulty, competitor traffic, backlink authority, toxic-link scores, live SERP results or AI-platform visibility scores are fabricated.
- Keyword intent, clustering, readiness and prioritization use visible heuristics. Review the accompanying note in each tool.
- AI prompt ideas are generated from templates. They are not copied from model prompt logs or clickstream datasets.
- Backlink, GSC and GA4 analysis works on CSV exports supplied by the user. Connect official APIs later if you need account-level data.
- Readability scoring is an English-language approximation. Robots parsing is simplified. The page fetcher does not execute JavaScript and some websites will reject it.
- The website has no user accounts, analytics, database or third-party AI API dependency. User input is processed in the browser except public URLs passed to the page-fetch function.

## Before public launch

- Add Cloudflare Turnstile and rate limiting to `/api/fetch`.
- Add a clear acceptable-use policy and privacy notice.
- Add tests for robots parsing, CSV imports, sitemap edge cases and redirect behaviour.
- Add authentication and quota controls before storing user projects or enabling shared crawls.
- For authenticated GSC/GA4 integration, implement OAuth with server-side token storage. Do not put private API secrets in browser JavaScript.
- For real-time keyword/SERP/backlink/AI-platform data, use licensed data providers or official APIs and display provenance, timestamp, country, device and coverage.

## License

This starter code is provided for your own project. Check third-party hosting, font and API terms before commercial use.
