const forbiddenSuffixes = ['.localhost', '.local', '.internal', '.test', '.invalid'];
function isPrivateIPv4(host) {
  const p = host.split('.').map(Number);
  if (p.length !== 4 || p.some(n => !Number.isInteger(n) || n < 0 || n > 255)) return false;
  const [a,b] = p;
  return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || (a === 198 && (b === 18 || b === 19));
}
function checkIp(ip) {
  const value = ip.toLowerCase().replace(/^\[|\]$/g, '');
  if (isPrivateIPv4(value) || value === '::' || value === '::1' || value.startsWith('fc') || value.startsWith('fd') || value.startsWith('fe80:') || value.startsWith('ff') || value.startsWith('::ffff:')) {
    throw new Error('Private, local or reserved IP address blocked.');
  }
}
async function resolvePublicHostname(host) {
  let current = host;
  for (let hop = 0; hop < 6; hop++) {
    const answers = [];
    for (const type of ['A', 'AAAA']) {
      const dnsUrl = `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(current)}&type=${type}`;
      const response = await fetch(dnsUrl, { headers: { Accept: 'application/dns-json' }, signal: AbortSignal.timeout(4000) });
      if (!response.ok) throw new Error('Could not safely resolve the target hostname.');
      const data = await response.json();
      answers.push(...(data.Answer || []));
    }
    const ips = answers.filter(a => a.type === 1 || a.type === 28).map(a => a.data);
    ips.forEach(checkIp);
    if (ips.length) return;
    const cname = answers.find(a => a.type === 5)?.data;
    if (cname) { current = cname.replace(/\.$/, ''); continue; }
    throw new Error('Target hostname did not resolve to a public IP address.');
  }
  throw new Error('Too many DNS aliases in target hostname.');
}
async function validateTarget(raw) {
  const u = new URL(raw);
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Only HTTP and HTTPS URLs are supported.');
  if (u.username || u.password) throw new Error('URLs with embedded credentials are not allowed.');
  if (u.port && !['80','443'].includes(u.port)) throw new Error('Only standard HTTP/HTTPS ports are allowed.');
  const host = u.hostname.toLowerCase().replace(/^\[|\]$/g, '').replace(/\.$/, '');
  if (!host || host === 'localhost' || forbiddenSuffixes.some(s => host.endsWith(s)) || host === 'metadata.google.internal') throw new Error('Local or reserved hostnames are not allowed.');
  if (host.includes(':')) checkIp(host);
  else if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) checkIp(host);
  else await resolvePublicHostname(host);
  return u;
}

export async function onRequestGet({ request }) {
  const headers = { 'Cache-Control': 'no-store' };
  try {
    const supplied = new URL(request.url).searchParams.get('url');
    if (!supplied) return Response.json({ error: 'Missing url parameter.' }, { status: 400, headers });
    let current = await validateTarget(supplied);
    const redirects = [];
    let response;
    for (let hop = 0; hop <= 5; hop++) {
      response = await fetch(current.toString(), {
        method: 'GET', redirect: 'manual', signal: AbortSignal.timeout(8000),
        headers: { 'User-Agent': 'ClearSEO-PageAudit/1.0', 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' }
      });
      if (![301,302,303,307,308].includes(response.status)) break;
      const location = response.headers.get('location');
      if (!location) break;
      if (hop === 5) throw new Error('Redirect limit exceeded (5 hops).');
      const next = await validateTarget(new URL(location, current).toString());
      redirects.push({ status: response.status, from: current.toString(), to: next.toString() });
      current = next;
    }
    const maxBytes = 1_500_000;
    const length = Number(response.headers.get('content-length') || 0);
    if (length > maxBytes) throw new Error('Page response is larger than the 1.5 MB inspection limit.');
    let body = '';
    if (response.body) {
      const reader = response.body.getReader();
      const chunks = []; let total = 0;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value.byteLength;
        if (total > maxBytes) { await reader.cancel(); throw new Error('Page response exceeded the 1.5 MB inspection limit.'); }
        chunks.push(value);
      }
      const joined = new Uint8Array(total); let offset = 0;
      for (const chunk of chunks) { joined.set(chunk, offset); offset += chunk.byteLength; }
      body = new TextDecoder('utf-8', { fatal: false }).decode(joined);
    }
    const exposed = {};
    ['content-type','content-length','cache-control','x-robots-tag','server','last-modified','location'].forEach(k => { const v = response.headers.get(k); if (v) exposed[k] = v; });
    return Response.json({ status: response.status, finalUrl: current.toString(), redirects, headers: exposed, contentType: response.headers.get('content-type') || '', body, bytes: new TextEncoder().encode(body).length }, { status: 200, headers });
  } catch (err) {
    const message = err?.name === 'TimeoutError' ? 'The target website took too long to respond.' : (err?.message || 'Could not fetch the URL.');
    return Response.json({ error: message }, { status: 400, headers });
  }
}
