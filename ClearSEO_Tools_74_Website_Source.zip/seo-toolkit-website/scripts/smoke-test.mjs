import assert from 'node:assert/strict';
import { tools } from '../src/tools.js';
import { runTool } from '../src/engine.js';

const byId = id => {
  const tool = tools.find(item => item.id === id);
  assert.ok(tool, `Tool not found: ${id}`);
  return tool;
};
const cases = [
  ['keyword-cleaner', { keywords: 'SEO Audit\nseo audit\nTechnical SEO' }],
  ['intent-classifier', { keywords: 'how to fix indexing\nbest seo tools\nseo software pricing' }],
  ['keyword-cluster', { keywords: 'technical seo audit\nseo technical audit\nseo content strategy' }],
  ['title-audit', { title: 'A practical technical SEO audit guide for large websites' }],
  ['meta-audit', { description: 'Learn how to audit large websites for crawling, indexing, structured data and content quality.' }],
  ['keyword-density', { content: 'Technical SEO is important. A technical SEO audit finds errors. This audit covers SEO.', keyword: 'technical seo' }],
  ['sitemap-generator', { urls: 'https://example.com/\nhttps://example.com/about', lastmod: '2026-11-03' }],
  ['gsc-analyzer', { csv: 'Top queries,Clicks,Impressions,CTR,Position\nseo audit,120,5000,2.4%,8.2' }],
  ['utm-builder', { url: 'https://example.com/page', source: 'newsletter', medium: 'email', campaign: 'november' }],
  ['ppc-match', { keywords: 'seo audit\ntechnical seo', match: 'Phrase' }],
  ['regex-builder', { terms: 'seo audit\ntechnical seo', mode: 'Contains any' }],
  ['content-brief', { topic: 'technical SEO', audience: 'SEO managers', intent: 'Informational', goal: 'Improve qualified leads' }],
  ['local-schema', { name: 'Example Business', type: 'LocalBusiness', url: 'https://example.com', city: 'Patna', country: 'IN' }]
];
for (const [id, input] of cases) {
  const result = await runTool(byId(id), input);
  assert.ok(result && typeof result.summary === 'string' && result.summary.length, `${id} did not return a summary`);
  console.log(`PASS ${id}: ${result.summary}`);
}
assert.equal(tools.length, 74, 'Expected exactly 74 tool entries');
console.log(`PASS tool catalogue: ${tools.length} tools`);
