import { cp, mkdir, rm } from 'node:fs/promises';

await rm('dist', { recursive: true, force: true });
await mkdir('dist/src', { recursive: true });
await cp('index.html', 'dist/index.html');
await cp('_headers', 'dist/_headers');
await cp('src/main.js', 'dist/src/main.js');
await cp('src/tools.js', 'dist/src/tools.js');
await cp('src/engine.js', 'dist/src/engine.js');
await cp('src/style.css', 'dist/src/style.css');
console.log('Static website built in ./dist');
