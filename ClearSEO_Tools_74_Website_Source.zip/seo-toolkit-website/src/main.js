import { categories, tools, toolCount } from './tools.js';
import { runTool, resultToCsv } from './engine.js';

const root = document.querySelector('#app');
let activeCategory = 'All tools';
let selectedTool = null;
let lastResult = null;
let formValues = {};
let busy = false;

const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g,'-');
const cats = ['All tools', ...categories];

function render() {
  const filtered = tools.filter(t => activeCategory === 'All tools' || t.category === activeCategory);
  root.innerHTML = `
    <div class="app-shell">
      <header class="topbar">
        <a class="brand" href="#" aria-label="ClearSEO home"><span class="brand-mark">C</span><span>ClearSEO<span class="brand-light">Tools</span></span></a>
        <div class="topbar-center"><span class="status-dot"></span><span>Free browser-based utilities</span><span class="topbar-divider"></span><span>${toolCount} tools</span></div>
        <a class="github-link" href="https://github.com/" target="_blank" rel="noreferrer">Build notes <span>↗</span></a>
      </header>
      <section class="hero">
        <div class="hero-copy">
          <div class="eyebrow"><span class="eyebrow-line"></span> SEO WORKSPACE / 2026</div>
          <h1>SEO work, without<br/><em>the black box.</em></h1>
          <p>Practical tools for technical SEO, content, keyword workflows and AI search readiness. Your data stays in your browser unless a tool needs to fetch a public page.</p>
          <div class="hero-points"><span>✓ No paid API keys</span><span>✓ Exportable reports</span><span>✓ Transparent heuristics</span></div>
        </div>
        <div class="hero-stat"><div class="stat-orbit"><div class="orbit-inner"><strong>${toolCount}</strong><span>TOOLS</span></div></div><div class="hero-stat-note">One workspace<br/>for everyday SEO tasks</div></div>
      </section>
      <main class="workspace">
        <aside class="sidebar">
          <div class="side-label">WORKSPACE</div>
          <button class="nav-item ${activeCategory==='All tools'?'active':''}" data-category="All tools"><span class="nav-icon">▦</span> All tools <span class="nav-count">${toolCount}</span></button>
          <div class="side-label category-label">TOOL CATEGORIES</div>
          ${categories.map((c,i)=>`<button class="nav-item ${activeCategory===c?'active':''}" data-category="${esc(c)}"><span class="nav-icon">${['⌕','◫','⌘','✎','↗','⌖','✳','▤'][i]}</span><span>${esc(c)}</span><span class="nav-count">${tools.filter(t=>t.category===c).length}</span></button>`).join('')}
          <div class="sidebar-foot"><span class="privacy-icon">◈</span><div><b>Privacy by design</b><small>Most processing happens locally in your browser.</small></div></div>
        </aside>
        <section class="main-panel">
          <div class="content-heading">
            <div><div class="eyebrow">TOOL LIBRARY</div><h2>${esc(activeCategory)}</h2><p>${activeCategory==='All tools'?'Choose a tool to run an SEO task.':'Tools for '+esc(activeCategory.toLowerCase())+'.'}</p></div>
            <div class="search-wrap"><span class="search-icon">⌕</span><input id="tool-search" type="search" placeholder="Search ${toolCount} tools..." autocomplete="off"/><kbd>/</kbd></div>
          </div>
          <div id="tool-area">${selectedTool ? renderToolPanel(selectedTool) : renderCards(filtered)}</div>
          <footer class="main-footer"><span>ClearSEO Tools · Independent utility suite</span><span>Estimates are labelled. No fabricated live metrics.</span></footer>
        </section>
      </main>
      <div class="toast" id="toast" role="status" aria-live="polite"></div>
    </div>`;
  bindBaseEvents();
  if (selectedTool) bindToolEvents();
}

function renderCards(list) {
  return `<div class="tool-grid" id="tool-grid">${list.map(t=>`
    <article class="tool-card" data-search="${esc((t.name+' '+t.description+' '+t.category).toLowerCase())}">
      <div class="card-top"><span class="tool-category">${esc(t.category)}</span><span class="card-arrow">↗</span></div>
      <h3>${esc(t.name)}</h3><p>${esc(t.description)}</p>
      <button class="open-tool" data-tool="${esc(t.id)}">Open tool <span>→</span></button>
    </article>`).join('')}</div>${list.length?'':'<div class="empty-state">No tools match that search.</div>'}`;
}

function renderToolPanel(t) {
  return `<div class="tool-workbench">
    <button class="back-link" id="back-to-tools">← Back to tools</button>
    <div class="workbench-head"><div><div class="eyebrow">${esc(t.category.toUpperCase())}</div><h2>${esc(t.name)}</h2><p>${esc(t.description)}</p></div><span class="tool-badge">LOCAL UTILITY</span></div>
    <div class="workbench-grid">
      <section class="input-card">
        <div class="section-title"><span class="step-no">01</span><div><b>Input data</b><small>Provide the values to analyze</small></div></div>
        <form id="tool-form">
          ${t.fields.map(f=>renderField(f)).join('')}
          <div class="form-actions"><button class="run-button" id="run-button" type="submit"><span>Run analysis</span><span>→</span></button><button class="reset-button" id="reset-button" type="button">Reset</button></div>
        </form>
      </section>
      <section class="output-card">
        <div class="section-title"><span class="step-no">02</span><div><b>Results</b><small>Analysis output and export</small></div></div>
        <div id="result-area">${lastResult ? renderResult(lastResult) : `<div class="result-empty"><div class="empty-icon">⌁</div><b>Results will appear here</b><p>Enter your data and run the tool to generate an output.</p></div>`}</div>
      </section>
    </div>
    <div class="method-note"><span>ⓘ</span><p><b>Method and data:</b> ${esc(t.note)}</p></div>
  </div>`;
}

function renderField(f) {
  const value = formValues[f.id] ?? '';
  if (f.type === 'select') {
    const opts = f.id === 'intent' ? ['Informational','Commercial','Transactional','Navigational','Local'] : f.id === 'tone' ? ['Professional','Friendly','Formal'] : f.id === 'type' ? ['LocalBusiness','Store','Restaurant','MedicalBusiness','ProfessionalService','Organization'] : f.id === 'stage' ? ['All','Awareness','Consideration','Decision','Implementation','Measurement'] : f.id === 'mode' ? ['Contains any','Match all','Exact'] : f.id === 'match' ? ['Broad','Phrase','Exact'] : f.id === 'platform' ? ['LinkedIn','X','Instagram','Facebook'] : ['Informational','Commercial','Transactional'];
    return `<label class="field"><span>${esc(f.label)}</span><select name="${esc(f.id)}">${opts.map(o=>`<option ${value===o || (!value&&o===f.placeholder)?'selected':''}>${esc(o)}</option>`).join('')}</select>${f.hint?`<small>${esc(f.hint)}</small>`:''}</label>`;
  }
  const type = f.type === 'url' ? 'url' : f.type === 'number' ? 'number' : 'text';
  const placeholder = esc(f.placeholder || '');
  if (f.type === 'textarea') return `<label class="field"><span>${esc(f.label)}</span><textarea name="${esc(f.id)}" rows="5" placeholder="${placeholder}">${esc(value)}</textarea>${f.hint?`<small>${esc(f.hint)}</small>`:''}</label>`;
  return `<label class="field"><span>${esc(f.label)}</span><input name="${esc(f.id)}" type="${type}" value="${esc(value)}" placeholder="${placeholder}" ${f.type==='number'?'min="0"':''}/>${f.hint?`<small>${esc(f.hint)}</small>`:''}</label>`;
}

function renderResult(result) {
  const rows = result.rows || [];
  let table = '';
  if (rows.length) {
    const cols = [...new Set(rows.slice(0,250).flatMap(r=>Object.keys(r)))];
    table = `<div class="table-wrap"><table><thead><tr>${cols.map(c=>`<th>${esc(c.replace(/_/g,' '))}</th>`).join('')}</tr></thead><tbody>${rows.slice(0,250).map(row=>`<tr>${cols.map(c=>`<td>${esc(Array.isArray(row[c])?row[c].join(' | '):typeof row[c]==='object'&&row[c]!==null?JSON.stringify(row[c]):row[c]??'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
  }
  return `<div class="result-summary"><span class="result-check">✓</span><b>${esc(result.summary || 'Analysis complete')}</b></div>${result.note?`<div class="result-note">${esc(result.note)}</div>`:''}${result.text?`<div class="result-text"><pre>${esc(result.text)}</pre></div>`:''}${table || '<div class="result-empty small-empty">No tabular rows were returned.</div>'}<div class="export-row"><button data-export="csv">↓ Export CSV</button><button data-export="json">↓ Export JSON</button><button data-export="txt">↓ Export TXT</button><button data-export="pdf">↓ Save PDF</button><button data-copy="1">Copy summary</button></div>`;
}

function bindBaseEvents() {
  root.querySelectorAll('[data-category]').forEach(btn=>btn.addEventListener('click',()=>{activeCategory=btn.dataset.category;selectedTool=null;lastResult=null;formValues={};render();}));
  root.querySelectorAll('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{selectedTool=tools.find(t=>t.id===btn.dataset.tool);lastResult=null;formValues={};render();}));
  const search=root.querySelector('#tool-search');
  search?.addEventListener('input',()=>{
    const term=search.value.toLowerCase().trim();
    if(selectedTool) return;
    const list=tools.filter(t=>(activeCategory==='All tools'||t.category===activeCategory)&&(t.name+' '+t.description+' '+t.category).toLowerCase().includes(term));
    root.querySelector('#tool-area').innerHTML=renderCards(list);
    root.querySelectorAll('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{selectedTool=tools.find(t=>t.id===btn.dataset.tool);lastResult=null;formValues={};render();}));
  });
  document.addEventListener('keydown',e=>{if(e.key==='/'&&document.activeElement.tagName!=='INPUT'&&document.activeElement.tagName!=='TEXTAREA'){e.preventDefault();root.querySelector('#tool-search')?.focus();}});
}

function bindToolEvents() {
  root.querySelector('#back-to-tools')?.addEventListener('click',()=>{selectedTool=null;lastResult=null;formValues={};render();});
  const form=root.querySelector('#tool-form');
  form?.querySelectorAll('input,textarea,select').forEach(el=>el.addEventListener('input',()=>{formValues[el.name]=el.value;}));
  form?.addEventListener('submit',async e=>{
    e.preventDefault();if(busy)return;
    const fd=new FormData(form);formValues=Object.fromEntries(fd.entries());
    busy=true;const btn=root.querySelector('#run-button');btn.disabled=true;btn.innerHTML='<span>Working...</span><span class="spinner"></span>';
    try { lastResult=await runTool(selectedTool,formValues); root.querySelector('#result-area').innerHTML=renderResult(lastResult); bindResultEvents(); }
    catch(err){root.querySelector('#result-area').innerHTML=`<div class="error-box"><b>Could not complete this analysis</b><p>${esc(err.message||'Unknown error')}</p></div>`;}
    finally {busy=false;btn.disabled=false;btn.innerHTML='<span>Run analysis</span><span>→</span>';}
  });
  root.querySelector('#reset-button')?.addEventListener('click',()=>{formValues={};lastResult=null;form.reset();root.querySelector('#result-area').innerHTML='<div class="result-empty"><div class="empty-icon">⌁</div><b>Results will appear here</b><p>Enter your data and run the tool to generate an output.</p></div>';});
  bindResultEvents();
}

function download(name, content, type) {
  const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();URL.revokeObjectURL(url);
}
function bindResultEvents() {
  root.querySelectorAll('[data-export]').forEach(btn=>btn.addEventListener('click',()=>{
    if(!lastResult)return;const fmt=btn.dataset.export;const id=selectedTool?.id||'seo-tool';
    if(fmt==='csv')download(`${id}-results.csv`,resultToCsv(lastResult),'text/csv;charset=utf-8');
    if(fmt==='json')download(`${id}-results.json`,JSON.stringify(lastResult,null,2),'application/json');
    if(fmt==='txt')download(`${id}-results.txt`,`${lastResult.summary||''}\n\n${lastResult.note||''}\n\n${lastResult.text||''}\n\n${resultToCsv(lastResult)}`,'text/plain;charset=utf-8');
    if(fmt==='pdf'){window.print();return;}
    showToast(`${fmt.toUpperCase()} export ready.`);
  }));
  root.querySelector('[data-copy]')?.addEventListener('click',async()=>{if(!lastResult)return;try{await navigator.clipboard.writeText(`${lastResult.summary||''}\n${lastResult.note||''}`);showToast('Summary copied.');}catch{showToast('Clipboard permission was not available.');}});
}
function showToast(text) { const el=root.querySelector('#toast');if(!el)return;el.textContent=text;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),1800); }

render();
