# ClearSEO Tools: Live karne ka process (Hinglish)

## 1. Local laptop par run karein

1. ZIP extract karein.
2. Node.js 20+ install karein.
3. Project folder mein terminal open karein.
4. Run karein:

```bash
npm run dev
```

5. Browser mein `http://localhost:4173` open karein.
6. Public URL check karne ke liye koi public website URL dein. Local/private network URLs intentionally block hain.

Build verify karne ke liye:

```bash
npm run build
npm run preview
```

## 2. Cloudflare Pages par publish karein

1. GitHub par free account banayein.
2. New repository banakar ZIP ke extracted project files upload/push karein.
3. Cloudflare Dashboard mein login karein.
4. **Workers & Pages → Create application → Pages → Connect to Git** select karein.
5. GitHub repository select karein.
6. Build settings:
   - Framework preset: `None`
   - Build command: `npm run build`
   - Build output directory: `dist`
7. Deploy select karein.
8. Deploy complete hone par `*.pages.dev` URL milega.
9. Live URL Response Checker aur Single-Page Technical SEO Audit test karein.
10. Custom domain ke liye domain ko Cloudflare mein add karke Pages project ke **Custom domains** section se connect karein.

Cloudflare Pages Functions ke liye `functions/api/fetch.js` root folder mein rehna zaroori hai. Iska endpoint `/api/fetch` hoga.

## 3. Vercel par publish karein

1. GitHub repository banayein aur source push karein.
2. Vercel Dashboard → **Add New → Project** kholein.
3. GitHub repository import karein.
4. Framework preset `Other` select karein. Build command `npm run build` aur output directory `dist` verify karein.
5. Deploy select karein.
6. `vercel.json` aur `api/fetch.js` ko repository mein rehne dein. API function public URL auditing ke liye use hota hai.

**Important:** Vercel Hobby plan ko Vercel personal, non-commercial use ke liye batata hai. Monetized production service ke liye plan/host ke current commercial terms check karein. Free hosting ko guaranteed business hosting na samjhein.

## 4. Public launch se pehle ye kaam zaroor karein

- `/api/fetch` ke liye Cloudflare Turnstile ya equivalent bot protection lagayein.
- API route par IP-based rate limit aur daily usage cap lagayein.
- Privacy Policy, Terms, Acceptable Use aur contact page publish karein.
- User se private URLs, internal IPs, admin URLs ya confidential content submit na karne ki warning dein.
- Google Search Console/GA4 OAuth integration add karne se pehle secure server-side token storage banayein.
- Real keyword volumes, SERP positions, competitor traffic, backlink metrics aur AI visibility ke liye licensed data source ya official API integrate karein.

## 5. Free version ki boundary

- 74 tools mein no paid API key required.
- CSV-based GSC/GA4/backlink reports tabhi authentic hongi jab aap valid exports upload/paste karenge.
- Keyword search volume, keyword difficulty, live PAA, competitor traffic aur web-wide plagiarism is starter mein available nahi hain.
- AI prompt builder templates se prompts generate karta hai. Ye ChatGPT/Gemini/Claude ke real search logs nahi hain.
- GEO readiness score editorial checklist hai, AI visibility score nahi.
- URL fetch server-side HTML inspect karta hai. Ye JavaScript-rendering crawler nahi hai.

## 6. Live test checklist

- [ ] Homepage desktop + mobile par open hota hai.
- [ ] All tools category count total 74 show hota hai.
- [ ] Keyword cleaner duplicate rows remove karta hai.
- [ ] Title/meta checker input length calculate karta hai.
- [ ] Sitemap generator valid XML draft deta hai.
- [ ] GSC/GA4 CSV analyzer sample CSV parse karta hai.
- [ ] JSON-LD generators valid JSON output dete hain.
- [ ] CSV, JSON aur TXT downloads open hote hain.
- [ ] Public URL checker 200/301/404 response inspect karta hai.
- [ ] Private/local URLs block hote hain.
- [ ] Terms, privacy, rate limits aur error handling production ready hain.
