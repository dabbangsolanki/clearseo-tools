import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dns from 'node:dns/promises';
import net from 'node:net';

const root = path.dirname(fileURLToPath(import.meta.url));
const useDist = process.argv.includes('--dist');
const staticRoot = path.join(root, useDist ? 'dist' : '.');
const mime = { '.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8','.svg':'image/svg+xml' };
function ipPrivate(ip) {
  const v = net.isIP(ip);
  if (v === 4) {
    const [a,b] = ip.split('.').map(Number);
    return a===0||a===10||a===127||a>=224||(a===169&&b===254)||(a===172&&b>=16&&b<=31)||(a===192&&b===168)||(a===100&&b>=64&&b<=127)||(a===198&&(b===18||b===19));
  }
  if (v === 6) return ip==='::1'||ip==='::'||/^f[cd]/i.test(ip)||/^fe80:/i.test(ip)||ip.startsWith('::ffff:');
  return false;
}
async function validateTarget(raw) {
  const u = new URL(raw);
  if (!['http:','https:'].includes(u.protocol)) throw new Error('Only HTTP and HTTPS URLs are supported.');
  if (u.username||u.password) throw new Error('URLs with embedded credentials are not allowed.');
  if (u.port&&!['80','443'].includes(u.port)) throw new Error('Only standard HTTP/HTTPS ports are allowed.');
  const host=u.hostname.toLowerCase().replace(/^\[|\]$/g,'').replace(/\.$/,'');
  if (!host||host==='localhost'||['.local','.localhost','.internal','.test','.invalid'].some(x=>host.endsWith(x))) throw new Error('Local or reserved hostnames are not allowed.');
  if (net.isIP(host)) { if(ipPrivate(host)) throw new Error('Private or local IP addresses are not allowed.'); }
  else {
    const ips=await dns.lookup(host,{all:true,verbatim:true});
    if (!ips.length||ips.some(x=>ipPrivate(x.address))) throw new Error('Host resolves to a private or local address and is blocked.');
  }
  return u;
}
async function fetchPublicPage(raw) {
  let current=await validateTarget(raw);const redirects=[];let response;
  for(let hop=0;hop<=5;hop++){
    response=await fetch(current,{redirect:'manual',signal:AbortSignal.timeout(12000),headers:{'User-Agent':'ClearSEO-PageAudit/1.0','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}});
    if(![301,302,303,307,308].includes(response.status))break;
    const loc=response.headers.get('location');if(!loc)break;if(hop===5)throw new Error('Redirect limit exceeded (5 hops).');
    const next=await validateTarget(new URL(loc,current).toString());redirects.push({status:response.status,from:current.toString(),to:next.toString()});current=next;
  }
  const max=1_500_000;const reader=response.body?.getReader();const chunks=[];let total=0;
  if(reader){while(true){const {done,value}=await reader.read();if(done)break;total+=value.byteLength;if(total>max){await reader.cancel();throw new Error('Page response exceeded the 1.5 MB inspection limit.');}chunks.push(value);}}
  const data=new Uint8Array(total);let pos=0;for(const c of chunks){data.set(c,pos);pos+=c.length;}
  const headers={};for(const k of ['content-type','content-length','cache-control','x-robots-tag','server','last-modified','location']){const v=response.headers.get(k);if(v)headers[k]=v;}
  const body=new TextDecoder().decode(data);
  return {status:response.status,finalUrl:current.toString(),redirects,headers,contentType:response.headers.get('content-type')||'',body,bytes:total};
}
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/api/fetch'){
    try{const target=url.searchParams.get('url');if(!target)throw new Error('Missing url parameter.');const data=await fetchPublicPage(target);res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));}
    catch(e){res.writeHead(400,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({error:e.name==='TimeoutError'?'The target website took too long to respond.':e.message||'Fetch failed.'}));}
    return;
  }
  let pathname=decodeURIComponent(url.pathname);if(pathname==='/')pathname='/index.html';
  const file=path.join(staticRoot,pathname.replace(/^\/+/,''));
  try{if(!file.startsWith(staticRoot))throw new Error('Invalid path');const info=await stat(file);if(!info.isFile())throw new Error('Not a file');const body=await readFile(file);res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(body);}
  catch{res.writeHead(404,{'Content-Type':'text/plain'});res.end('Not found');}
});
const port=Number(process.env.PORT||4173);server.listen(port,'0.0.0.0',()=>console.log(`ClearSEO Tools running at http://localhost:${port}`));
